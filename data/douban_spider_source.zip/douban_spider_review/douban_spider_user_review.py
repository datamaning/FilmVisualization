﻿#!/usr/bin/env python
# -*- coding:utf-8 -*-

import string
import re
import socket
import urllib2
import cookielib
import random

import threading
import Queue
import time
import datetime

import os
import sys

reload(sys)

sys.setdefaultencoding('utf8')
SHARE_Q = Queue.Queue()
WORKER_THREAD_NUM = 5

review_url = "http://movie.douban.com/review/{review_id}/"

user_agents = [
'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0) AddSugarSpiderBot www.idealobserver.com',
'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0)',
'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.2)',
'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)',
'Mozilla/5.0 (Windows; U; Windows NT 5.2) Gecko/2008070208 Firefox/3.0.1',
'Mozilla/5.0 (Windows; U; Windows NT 5.1) Gecko/20070803 Firefox/1.5.0.12',
'Mozilla/5.0 (Macintosh; PPC Mac OS X; U; en) Opera 8.0',
'Opera/8.0 (Macintosh; PPC Mac OS X; U; en)',
'Opera/9.27 (Windows NT 5.2; U; zh-cn)',
'Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.2.149.27 Safari/525.13',
'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.12) Gecko/20080219 Firefox/2.0.0.12 Navigator/9.0.0.6',
'Mozilla/5.0 (iPhone; U; CPU like Mac OS X) AppleWebKit/420.1 (KHTML, like Gecko) Version/3.0 Mobile/4A93 Safari/419.3',
'Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/525.13 (KHTML, like Gecko) Version/3.1 Safari/525.13'

'zspider/0.9-dev http://feedback.redkolibri.com/',
'Xaldon_WebSpider/2.0.b1',
'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) Speedy Spider (http://www.entireweb.com/about/search_tech/speedy_spider/)',
'Mozilla/5.0 (compatible; Speedy Spider; http://www.entireweb.com/about/search_tech/speedy_spider/)',
'Speedy Spider (Entireweb; Beta/1.3; http://www.entireweb.com/about/search_tech/speedyspider/)',
'Speedy Spider (Entireweb; Beta/1.2; http://www.entireweb.com/about/search_tech/speedyspider/)',
'Speedy Spider (Entireweb; Beta/1.1; http://www.entireweb.com/about/search_tech/speedyspider/)',
'Speedy Spider (Entireweb; Beta/1.0; http://www.entireweb.com/about/search_tech/speedyspider/)',
'Speedy Spider (Beta/1.0; www.entireweb.com)',
'Speedy Spider (http://www.entireweb.com/about/search_tech/speedy_spider/)',
'Speedy Spider (http://www.entireweb.com/about/search_tech/speedyspider/)',
'Speedy Spider (http://www.entireweb.com)',
'Sosospider+(+http://help.soso.com/webspider.htm)',
'sogou spider',
'Nusearch Spider (www.nusearch.com)',
'nuSearch Spider (compatible; MSIE 4.01; Windows NT)',
'lmspider (lmspider@scansoft.com)',
'lmspider lmspider@scansoft.com',
'ldspider (http://code.google.com/p/ldspider/wiki/Robots)',
'iaskspider/2.0(+http://iask.com/help/help_index.html)',
'iaskspider',
'hl_ftien_spider_v1.1',
'hl_ftien_spider',
'FyberSpider (+http://www.fybersearch.com/fyberspider.php)',
'FyberSpider',
'everyfeed-spider/2.0 (http://www.everyfeed.com)',
'envolk[ITS]spider/1.6 (+http://www.envolk.com/envolkspider.html)',
'envolk[ITS]spider/1.6 ( http://www.envolk.com/envolkspider.html)',
'Baiduspider+(+http://www.baidu.com/search/spider_jp.html)',
'Baiduspider+(+http://www.baidu.com/search/spider.htm)',
'BaiDuSpider',
]


class UserMapThread(threading.Thread) :
    def __init__(self, func) :
        super(UserMapThread, self).__init__()
        self.m_func = func
        
    def run(self) :
        self.m_func()
        
        
def get_page(url, flag = False) :
    if flag :
        fin = file('web.in', 'r')
        page = fin.read()
        fin.close()
        return page
    try :
        cookie_support= urllib2.HTTPCookieProcessor(cookielib.CookieJar())
        opener = urllib2.build_opener(cookie_support,urllib2.HTTPHandler)
        urllib2.install_opener(opener)
        agent = random.choice(user_agents)
        opener.addheaders = [("User-agent",agent),("Accept","*/*"),('Referer','http://www.google.com')]
        
        page = opener.open(url).read().decode("utf-8")
    except urllib2.URLError, e :
        if hasattr(e, "code"):
            print "The server couldn't fulfill the request."
            print "Error code: %s" % e.code
        elif hasattr(e, "reason"):
            print "We failed to reach a server. Please check your url and read the Reason"
            print "Reason: %s" % e.reason
        print '-----------------------------------------------------------------------'
        print url
        print '-----------------------------------------------------------------------'
        return ''
    return page


def get_review_info(review_id) :
    
    f_name = 'review_info/' + review_id + '.out'  
    if os.path.exists(f_name) == False :
        # get the web page
        url = review_url.format(review_id = review_id)
        print url
        
        #page = get_page(url, True)
        page = get_page(url)
        
        # find the information
        name_list = re.findall(r'<title>(.*)</title>', page, re.S)
        review_list = re.findall(r'<div property="v:description" class="">(.*)</div>', page)
        score_list = re.findall(r'<span property="v:rating" class="main-title-hide">(\d)</span>', page)
        
        score, name, review = '?', '', ''
        if score_list :
            score = score_list[0]
        if name_list :
            name = name_list[0].strip()
        if review_list :
            review = re.sub(r'<br/>', '', review_list[0])
        
        fout = file(f_name, 'w')
        fout.write(score + '\n' + name + '\n' + review)
        fout.close()
        print review_id + ' done ...'
        return True
    print review_id + ' exist ...'
    return False

    
def worker() :
    global SHARE_Q
    while not SHARE_Q.empty() :
        review_id = SHARE_Q.get()
        flag = get_review_info(review_id)
        if flag :
            time.sleep(random.uniform(5.0, 10.0))
        SHARE_Q.task_done() 


def main() :
    global SHARE_Q
    threads = []
    f_review_list = file('review_list.in', 'r')
    #f_review_list = file('review_list_sub.in', 'r')
    
    for line in f_review_list.readlines() :
        vect = line.split('|')
        review_id = vect[2][:-1]
        SHARE_Q.put(review_id)
        
    for i in xrange(WORKER_THREAD_NUM) :
        thread = UserMapThread(worker)
        thread.start()
        threads.append(thread)
        
    for thread in threads :
        thread.join()
    SHARE_Q.join()
    

if __name__ == '__main__':
    main()
    

